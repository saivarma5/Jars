package com.cognizant.login;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController extends HttpServlet {
	
	@RequestMapping(value="/" , method=RequestMethod.GET)
     public String start() {
    	 return "Login";
     }
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String validate(User user,Model model) {
		Map<String,String> al=new HashMap<String,String>();
		al.put("shanmukhasai007@gmail.com","saivarma");
		al.put("ravitejavarma@gmail.com","raviteja");
		Set<Map.Entry<String,String>> set=al.entrySet();
		String email = user.getEmail();
		String password = user.getPassword();
		int count=0;
		for(Map.Entry<String, String> a:set){
			if(a.getKey().equals(email)&&a.getValue().equals(password)){
				model.addAttribute("email",a.getKey());
				return "loginsuccess";
			}
			
		}
		if(count==0) {
			model.addAttribute("errorMessage","Invalid email/Password please try again");
			return "Login";
		}
		return null;
	}

}
