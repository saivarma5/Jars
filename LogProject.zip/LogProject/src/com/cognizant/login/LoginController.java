package com.cognizant.login;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginController extends HttpServlet {
	


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Map<String,String> al=new HashMap<String,String>();
		al.put("shanmukhasai007@gmail.com","saivarma");
		al.put("ravitejavarma@gmail.com","raviteja");
		Set<Map.Entry<String,String>> set=al.entrySet();
		/*ArrayList <String> al=new ArrayList<String>();
		al.add("shanmukhasai007@gmail.com");
		al.add("ravitejavarma@gmail.com");
		ArrayList<String> al2=new ArrayList<String>();
		al2.add("saivarma");
		al2.add("raviteja");*/
		String email = req.getParameter("Email");
		String password = req.getParameter("password");
		int count=0;
		for(Map.Entry<String, String> a:set){
			if(a.getKey().equals(email)&&a.getValue().equals(password)){
				HttpSession session = req.getSession();
				session.setAttribute("Email",email );
				RequestDispatcher rd = req.getRequestDispatcher("loginsuccess.jsp");
				rd.forward(req, resp);
				count++;
			}
			
		}
		if(count==0) {
		/*	HttpSession session = req.getSession();
			session.setAttribute("response","incorrect" );
			 System.out.println("Username or Password incorrect");
			RequestDispatcher rd = req.getRequestDispatcher("Login.jsp");
			rd.include(req, resp);*/
			req.setAttribute("errorMessage","User ID or Password is Incorrect please try again");
			RequestDispatcher rd = req.getRequestDispatcher("Login.jsp");
			rd.forward(req, resp);
	/*		resp.sendRedirect("loginfail.html");*/
		}
		/*int count=0;
		for(int i=0;i<al.size();i++){
			if(al.get(i).equals(email)&&al2.get(i).equals(password)){
				HttpSession session = req.getSession();
				session.setAttribute("Email",email );
				RequestDispatcher rd = req.getRequestDispatcher("loginsuccess.jsp");
				rd.forward(req, resp);
				count++;
			}
		}
		if(count==0){
			resp.sendRedirect("loginfail.html");
		}
			*/
		
	}

	

}
